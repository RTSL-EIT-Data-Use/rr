# Summarize Data ----------------------------------------------------------

epi_summ <- line_list %>%
  group_by(epi_year, epi_week, state_of_residence, result_fc) %>%
  summarise(
    suspected = n(),                                          
    confirmed = sum(result_fc == "Positive", na.rm = TRUE),
    deaths = sum(outcome == "Dead" & result_fc == "Positive", na.rm = TRUE),
    number_lga_of_residence = n_distinct(lga_of_residence),
    .groups = "drop"
  )

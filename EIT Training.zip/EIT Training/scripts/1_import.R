# Import Data -------------------------------------------------------------


# Import line list from the R project folder
# line_list <- read_excel("linelist.xlsx")

# file <- list.files(
#   path = "\data",
#   pattern = "\\.xlsx$",
#   full.names = TRUE
# )
# 
# line_list <- read_excel(file[1])

line_list <- import(here::here("data","linelist.xlsx"))
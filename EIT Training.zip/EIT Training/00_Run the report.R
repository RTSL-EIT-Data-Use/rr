###############################################################################
######                    Sitrep                 ###### 
###############################################################################

########################### 1. Update User input ###############################

## 1. Enter any date within the week you'd like to generate the report for
report_date <- as.Date("2026-06-03")


########################## 2. Generate the SitRep (RMD) #############################

#Generated report should be saved under "report" folder in this directory.
rmarkdown::render(here::here('scripts', 'sitrep.Rmd'),
                 output_file = here::here("report",
                                          paste0("Sitrep_",
                                                 lubridate::isoyear(report_date), "_W",
                                                 sprintf("%02d", lubridate::isoweek(report_date)),
                                                 ".docx")))
